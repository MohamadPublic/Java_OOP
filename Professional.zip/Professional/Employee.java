public abstract class Employee extends Person{

    //instance variables
    private String employeeID; //fixed
    private String jobTitle; //able to change

    //constructor for filled position
    public Employee(String name, String socialSecurityNumber, int age, String gender, String address, String telephoneNumber, String employeeID, String jobTitle){
        super(name, socialSecurityNumber, age, gender, address, telephoneNumber);
        this.employeeID = employeeID;
        this.jobTitle = jobTitle;
    }

    //constructor for unstaffed position
    public Employee(String employeeID, String jobTitle){
        super();
        this.employeeID = employeeID;
        this.jobTitle = jobTitle;
    }

    //getters
    public String getEmployeeID(){
        return employeeID;
    }

    public String getJobTitle(){
        return jobTitle;
    }

    //setters
    //we assume that all insance variables are fixed except jobTitle
    public void changeTitle(String newTitle){
        this.jobTitle = newTitle;
    }


    //abstract method declaration
    public abstract double salaryEarnedThisWeek(); //forces each child class to have a salary method that returns a double
    
    public abstract double vacationDaysEarnedThisWeek(); //forces each child class to have a vacationTime method that returns a double

    public abstract double insuranceContributionEarnedThisWeek(); //forces each child class to have an insurnaceContribution method that returns a double

}