public class Application{

    
    public static void display(Employee[] data){

        for (int i=0; i<data.length;i++){
            System.out.println("---------------");
            System.out.println("Printing Data for Employee " + (i+1));
            System.out.println("Name: " + data[i].getName());
            System.out.println("SSN: " + data[i].getSocialSecurityNumber());
            System.out.println("Employee ID: " + data[i].getEmployeeID());
            System.out.println("Title: " + data[i].getJobTitle());
            System.out.println("Weekly Salary: " + data[i].salaryEarnedThisWeek());
            System.out.println("Vacation Days Per Week: " + data[i].vacationDaysEarnedThisWeek());
            System.out.println("Insurance Contributions Per Week: " + data[i].insuranceContributionEarnedThisWeek());
        }
    }
    

    public static void main(String[] args){

        Employee[] anArray;
        anArray = new Employee[3];

        Professional John; //if we store as an employee, we will lose some methods and instance variables
        Nonprofessional Mike;
        Nonprofessional unfilled;

        John = new Professional("John Smith","64367347", 42, "Male", "123 Sesame Street", "432523523523", "K376523", "Full-Stack Developer", 15824.50, 30, 0.003);
        Mike = new Nonprofessional("Mike Sellinger", "2098562367", 32, "Male", "421 Main Rd.", "8906478902", "J24821254", "Janitor", 15.50, 37.5, 0.025, 1.5);
        unfilled = new Nonprofessional("K25235", "Front-end Developer", 55.75, 40, 0.03, 1.5);

        anArray[0] = John;
        anArray[1] = Mike;
        anArray[2] = unfilled;

        display(anArray);

        Mike.changeTitle("CEO");
        Mike.changeHourlyRate(600);
        Mike.updateAge();

        unfilled.setName("Sally Clease");
        unfilled.setSocialSecurityNumber("532421451");
        unfilled.setGender("Female");
        unfilled.setAge(31);
        unfilled.setNewAddress("128 Sesame Blvd.");
        unfilled.setNewTelephoneNumber("5632562645");

        unfilled.setName("TESTING");
        
        display(anArray);
    }
}