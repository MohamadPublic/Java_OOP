public class Person{

    //instance variables
    private String name; //fixed
    private String socialSecurityNumber; //fixed
    private int age; //can change
    private String gender; //fixed
    private String address; //can change
    private String telephoneNumber; //can change

    //constructor;
    public Person(String name, String socialSecurityNumber, int age, String gender, String address, String telephoneNumber){
        this.name = name;
        this.socialSecurityNumber = socialSecurityNumber;
        this.age = age;
        this.gender = gender;
        this.address = address;
        this.telephoneNumber = telephoneNumber;
    }
    
    //constructor for unstaffed position
    public Person(){
        this.name = "UNSTAFFED";
        this.socialSecurityNumber = "NA";
        this.age = 0;
        this.gender = "NA";
        this.address = "NA";
        this.telephoneNumber = "NA";
    }

    //getters
    public String getName(){
        return name;
    }

    public String getSocialSecurityNumber(){
        return socialSecurityNumber;
    }

    public int getAge(){
        return age;
    }

    public String getGender(){
        return gender;
    }

    public String getAddress(){
        return address;
    }

    public String getTelephoneNumber(){
        return telephoneNumber;
    }


    //setters with a one-time use (to be used when filling an unstaffed position)
    public void setName(String newName){
        if (this.name == "UNSTAFFED"){
            this.name = newName;
        }
    }

    public void setSocialSecurityNumber(String newSSN){
        if (this.socialSecurityNumber == "NA"){
            this.socialSecurityNumber = newSSN;
        }
    }

    public void setGender(String newGender){
        if (this.gender == "NA"){
            this.gender = newGender;
        }
    }

    public void setAge(int age){
        if(this.age == 0){
            this.age = age;
        }

    }

    //setters (used for information that can be updated)
    public void updateAge(){
        age++;
    }

    public void setNewAddress(String newAddress){
        address = newAddress;
    }

    public void setNewTelephoneNumber(String newNum){
        telephoneNumber = newNum;
    }   

}