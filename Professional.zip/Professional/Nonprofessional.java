public class Nonprofessional extends Employee{
    //instance variables
    private double hourlyRate; //able to change
    private double weeklyHours; //able to change
    private double vacationDayProportianlityConstant; //able to change
    private double contributionConstant; //assume this is fixed by contract with insurance company


    //constructor
    public Nonprofessional(String name, String socialSecurityNumber, int age, String gender, String address, String telephoneNumber, String employeeID, String jobTitle, double hourlyRate, double weeklyHours, double vacationDayProportianlityConstant, double contributionConstant){
        super(name, socialSecurityNumber, age, gender, address, telephoneNumber,employeeID, jobTitle );
        this.hourlyRate = hourlyRate;
        this.weeklyHours = weeklyHours;
        this.vacationDayProportianlityConstant = vacationDayProportianlityConstant;
        this.contributionConstant = contributionConstant;
    }
    
    //constructor for unstaffed position
    public Nonprofessional(String employeeID, String jobTitle, double hourlyRate, double weeklyHours, double vacationDayProportianlityConstant, double contributionConstant){
        super(employeeID, jobTitle );
        this.hourlyRate = hourlyRate;
        this.weeklyHours = weeklyHours;
        this.vacationDayProportianlityConstant = vacationDayProportianlityConstant;
        this.contributionConstant = contributionConstant;
    }

    //getters
    public double getHourlyRate(){
        return hourlyRate;
    }

    public double getWeeklyHours(){
        return weeklyHours;
    }

    public double getVacationDayProportionalityConstant(){
        return vacationDayProportianlityConstant;
    }

    public double getContributionConstant(){
        return contributionConstant;
    }

    //setters
    //we assume that the employer can change the hourly rate, weekly hours, and vacation day constant for nonprofessional employees

    public void changeHourlyRate(double newRate){
        this.hourlyRate = newRate;
    }

    public void changeHours(double newHours){
        this.weeklyHours = newHours;
    }

    public void changeVacationConstant(double newConstant){
        this.vacationDayProportianlityConstant = newConstant;
    }

    //required methods by superclass employee
    public double salaryEarnedThisWeek(){
        return hourlyRate*weeklyHours;
    }

    public double vacationDaysEarnedThisWeek(){
        return vacationDayProportianlityConstant * weeklyHours;
    }

    public double insuranceContributionEarnedThisWeek(){
        return contributionConstant * weeklyHours;
    }

}