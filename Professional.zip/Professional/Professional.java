public class Professional extends Employee{

    //instance variables
    private double monthlySalary; //able to change
    private int vacationDays; // able to change
    private double contributionConstant; //assume this is fixed by contract with insurance company

    //constructor
    public Professional(String name, String socialSecurityNumber, int age, String gender, String address, String telephoneNumber, String employeeID, String jobTitle, double monthlySalary, int vacationDays, double contributionConstant){
        super(name, socialSecurityNumber, age, gender, address, telephoneNumber,employeeID, jobTitle );
        this.monthlySalary = monthlySalary;
        this.vacationDays = vacationDays;
        this.contributionConstant = contributionConstant;
    }
    
    //constructor for unstaffed position
    public Professional(String employeeID, String jobTitle, double monthlySalary, int vacationDays, double contributionConstant){ //maybe we want this position solidified before someone has been hired for it!
        super(employeeID, jobTitle );
        this.monthlySalary = monthlySalary;
        this.vacationDays = vacationDays;
        this.contributionConstant = contributionConstant;
    }

    //getters
    public double getMonthlySalary(){
        return monthlySalary;
    }

    public int getVacationDays(){
        return vacationDays;
    }

    public double getContributionConstant(){
        return contributionConstant;
    }

    //setters
    //we assume that the employer is able to change the professional employee's salary and vacation days

    public void changeMonthlySalary(double newSalary){
        this.monthlySalary = newSalary;
    }
    
    public void changeVacationDays(int newVacationDays){
        this.vacationDays = newVacationDays;
    }

    //required methods by superclass Employee

    //assuming 4 weeks per month
    public double salaryEarnedThisWeek(){
        return monthlySalary/4;
    }

    //52 weeks per year
    public double vacationDaysEarnedThisWeek(){
        return vacationDays/52.0;
    }

    //assuming that insurnace contribution is proportional to monthlty salary for professionals
    public double insuranceContributionEarnedThisWeek(){
        return contributionConstant*monthlySalary; 
    }

}