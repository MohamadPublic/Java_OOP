public class Application{

    public static void display(Person[] data){

        for (int i =0; i< data.length; i++){
            System.out.println("-------------------------");
            System.out.println("Displaying Data for Person " + (i+1));
            System.out.println("Name: " + data[i].getName());
            System.out.println("Social Security Number: " + data[i].getSocialSecurityNumber());
            System.out.println("Age: " + data[i].getAge());
            System.out.println("Gender: " + data[i].getGender());
            System.out.println("Address: " + data[i].getAddress());
            System.out.println("Telephone Number: " + data[i].getTelephoneNumber());

            if (data[i] instanceof HourlyEmployee){ //Not all instances are necessarily hourly employees, we must check this
                
                HourlyEmployee tmp = (HourlyEmployee) data[i];
                System.out.println("Department: " + tmp.getDepartment());
                System.out.println("Job Title: " + tmp.getJobTitle());
                System.out.println("Year of Hire: " + tmp.getYearOfHire());
                System.out.println("Hourly Rate: " + tmp.getHourlyRate());
                System.out.println("Hours Worked: " + tmp.getgHoursWorked());
                System.out.println("Union Dues: " + tmp.getUnionDues());

            }

            else if (data[i] instanceof SalariedEmployee){
                SalariedEmployee tmp = (SalariedEmployee) data[i]; //cast to SalariedEmployee to regain methods
                System.out.println("Department: " + tmp.getDepartment());
                System.out.println("Job Title: " + tmp.getJobTitle());
                System.out.println("Year of Hire: " + tmp.getYearOfHire());
                System.out.println("Salary: " + tmp.getSalary());

            }

            else if (data[i] instanceof Employee){
                Employee tmp = (Employee) data[i];
                System.out.println("Department: " + tmp.getDepartment());
                System.out.println("Job Title: " + tmp.getJobTitle());
                System.out.println("Year of Hire: " + tmp.getYearOfHire());
            }

            else if (data[i] instanceof Student){
                Student tmp = (Student) data[i];
                System.out.println("Department: " + tmp.getMajor());
                System.out.println("Job Title: " + tmp.getGPA());
                System.out.println("Year of Hire: " + tmp.getYearOfGraduation());
            }



    }}

    public static void main(String[] args){
        Person[] anArray;
        anArray = new Person[5];
    
        Person John;
        Student Mohamad;
        Employee Mike;
        HourlyEmployee Sally;
        SalariedEmployee Alice;
    
        John = new Person("John Smith", "5851234",41,"Male","123 Sesame St.", "1231238911");
        Mohamad = new Student("Mohamad Ahmad", "57923457", 21, "Male","[Redacted], Ottawa ON", "123242142", 9.8, "Mathematics", 2021);
        Mike = new Employee("Mike Clease", "555555011", 71, "Female", "123 Clease Ave", "31231321313", "Mathematics", "Full Professor",2020);
        Sally = new HourlyEmployee("Sally Adams", "5543255011", 35, "F", "128 Clease Ave", "317534721313", "Computer Science", "Associate Professor", 2012, 120.75, 12, 300);
        Alice = new SalariedEmployee("Alice Clease", "55562345011", 36, "Female", "129 Clease Ave", "316786513", "Biology", "Part-Time Professor",2020, 150000);
        
        anArray[0] = John;
        anArray[1] = Mohamad;
        anArray[2] = Mike;
        anArray[3] = Sally;
        anArray[4] = Alice;

        display(anArray);}
    }
