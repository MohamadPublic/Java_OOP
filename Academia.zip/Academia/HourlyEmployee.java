public class HourlyEmployee extends Employee{

    //instance variables
    private double hourlyRate; // can change
    private double hoursWorked; // can change
    private double unionDues; // can change

    //constructor
    public HourlyEmployee(String name, String socialSecurityNumber, int age, String gender, String address, String telephoneNumber, String department, String jobTitle, int yearOfHire, double hourlyRate, double hoursWorked, double unionDues){
        super(name, socialSecurityNumber, age, gender, address, telephoneNumber, department, jobTitle, yearOfHire);
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
        this.unionDues = unionDues;
    }

    //getters
    public double getHourlyRate(){
        return hourlyRate;
    }

    public double getgHoursWorked(){
        return hoursWorked;
    }

    public double getUnionDues(){
        return unionDues;
    }

    //setters
    //Note that hourly rate, hours worked, and union dues are all subject to change

    public void updateHourlyRate(double newRate){
        this.hourlyRate = newRate;
    }

    public void updateHoursWorked(double newHours){
        this.hoursWorked = newHours;
    }

    public void updateUnionDues(double newDues){
        this.unionDues = newDues;
    }
}