public class Student extends Person{

    //Specialized instance variables
    private double GPA; //can change
    private String major; //can change
    private int yearOfGraduation; //can change

    //Constructor
    public Student(String name, String socialSecurityNumber, int age, String gender, String address, String telephoneNumber, double GPA, String major, int yearOfGraduation){
        super(name, socialSecurityNumber, age, gender, address, telephoneNumber);
        this.GPA = GPA;
        this.major = major;
        this.yearOfGraduation = yearOfGraduation;
    }

    //Getters
    public double getGPA(){
        return GPA;
    }

    public String getMajor(){
        return major;
    }

    public int getYearOfGraduation(){
        return yearOfGraduation;
    }

    //Setters
    // note that GPA, major, and yearOfGraduation are all subject to change

    public void updateGPA(double newGPA){
        GPA = newGPA;
    }

    public void updateMajor(String newMajor){
        major = newMajor;
    }

    public void updateYearOfGraduation(int newYear){
        yearOfGraduation = newYear;
    }

}