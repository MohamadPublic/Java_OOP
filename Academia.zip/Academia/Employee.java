public class Employee extends Person{
    
    //instance variables
    private String department; // fixed (assumption)
    private String jobTitle; // can be updated (assumption)
    private int yearOfHire; // fixed

    //constructor
    public Employee(String name, String socialSecurityNumber, int age, String gender, String address, String telephoneNumber, String department, String jobTitle, int yearOfHire){
        super(name, socialSecurityNumber, age, gender, address, telephoneNumber);

        this.department = department;
        this.jobTitle = jobTitle;
        this.yearOfHire = yearOfHire;
    }

    //getters
    public String getDepartment(){
        return department;
    }

    public String getJobTitle(){
        return jobTitle;
    }

    public int getYearOfHire(){
        return yearOfHire;
    }

    //setters
    public void setJobTitle(String newTitle){
        this.jobTitle = newTitle;
    }
}