public class SalariedEmployee extends Employee{

    //instance variables
    private double salary; // can change

    //constructor
    public SalariedEmployee(String name, String socialSecurityNumber, int age, String gender, String address, String telephoneNumber, String department, String jobTitle, int yearOfHire, double salary){
        super(name, socialSecurityNumber, age, gender, address, telephoneNumber, department, jobTitle, yearOfHire);
        this.salary = salary;
    }

    //getters
    public double getSalary(){
        return salary;
    }

    //setters
    public void updateSalary(double newSalary){
        this.salary = newSalary;
    }
}